mpiexec.mpich --hostfile mpd.hosts $1
