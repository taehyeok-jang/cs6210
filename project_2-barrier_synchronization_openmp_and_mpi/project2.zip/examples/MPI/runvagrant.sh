NP="4"
mpiexec.mpich -np $NP --hostfile mpd.hosts.vagrant $1

# ./runvagrant.sh ./hello_world
