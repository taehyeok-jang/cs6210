#!/bin/sh

cd ../..
./assignfiletoallvm.py memory/test/testcases/
